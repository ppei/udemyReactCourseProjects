var React = require('react-native');
var Main = require('./src/main');
var {AppRegistry} = React;

AppRegistry.registerComponent('authentication', () => Main);
